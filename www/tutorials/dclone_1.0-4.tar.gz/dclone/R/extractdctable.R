extractdctable <-
function(x, ...)
UseMethod("extractdctable")

