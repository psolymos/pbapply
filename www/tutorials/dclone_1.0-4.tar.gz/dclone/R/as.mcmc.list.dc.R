as.mcmc.list.dc <-
function (x, ...) 
    UseMethod("as.mcmc.list.dc")

