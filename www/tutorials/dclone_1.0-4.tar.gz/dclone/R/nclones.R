nclones <-
function(x, ...)
{
    UseMethod("nclones")
}
