errlines <-
function(x, ...)
    UseMethod("errlines")
