dclone <-
function(x, n.clones=1, ...)
UseMethod("dclone")
