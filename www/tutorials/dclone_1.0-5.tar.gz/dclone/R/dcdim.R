dcdim <-
function(x)
{
    class(x) <- c("dcdim", class(x))
    x
}
