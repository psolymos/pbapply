updated.model <-
function(object, ...)
{
    UseMethod("updated.model")
}
