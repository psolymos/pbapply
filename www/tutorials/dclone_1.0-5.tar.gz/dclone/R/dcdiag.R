dcdiag <-
function(x, ...)
UseMethod("dcdiag")
