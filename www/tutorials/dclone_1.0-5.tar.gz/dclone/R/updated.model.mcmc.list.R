updated.model.mcmc.list <- 
function(object, ...) 
{
    attr(object, "updated.model")
}
