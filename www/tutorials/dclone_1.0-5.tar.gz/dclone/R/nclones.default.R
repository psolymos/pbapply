nclones.default <-
function(x, ...)
{
    attr(x, "n.clones")
}
