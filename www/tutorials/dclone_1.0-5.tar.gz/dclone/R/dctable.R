dctable <-
function(x, ...)
UseMethod("dctable")
