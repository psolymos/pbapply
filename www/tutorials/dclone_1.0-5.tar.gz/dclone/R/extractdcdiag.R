extractdcdiag <-
function(x, ...)
UseMethod("extractdcdiag")

